﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;
using System.Data.SqlClient;

namespace WebApplication1.Controllers
{
    public class parkingsController : Controller
    {
        private ProjectEntities1 db = new ProjectEntities1();

        // GET: parkings
        public ActionResult Index()
        {
            return View(db.parkings.ToList());
        }

        // GET: parkings/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            parking parking = db.parkings.Find(id);
            if (parking == null)
            {
                return HttpNotFound();
            }
            return View(parking);
        }

        // GET: parkings/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: parkings/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,Name,MobileNumber,Vehicletype,VehicleNumber,Brand,VehicleModel,Color,ParkingSpotNumber,Date")] parking parking)
        {
            if (ModelState.IsValid)
            {
                db.parkings.Add(parking);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(parking);
        }

        // GET: parkings/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            parking parking = db.parkings.Find(id);
            if (parking == null)
            {
                return HttpNotFound();
            }
            return View(parking);
        }

        // POST: parkings/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Name,MobileNumber,Vehicletype,VehicleNumber,Brand,VehicleModel,Color,ParkingSpotNumber,Date")] parking parking)
        {
            if (ModelState.IsValid)
            {

                try
                {
                    db.Entry(parking).State = EntityState.Modified;

                    db.SaveChanges();

                }
                catch (Exception )
                {
                    Console.WriteLine("Slot is booked");

                }
                return RedirectToAction("Index");
            }
            return View(parking);
        }

        // GET: parkings/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            parking parking = db.parkings.Find(id);
            if (parking == null)
            {
                return HttpNotFound();
            }
            return View(parking);
        }

        // POST: parkings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            parking parking = db.parkings.Find(id);
            db.parkings.Remove(parking);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult Payment()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Payment(payment f)
        {
            parking parking = db.parkings.FirstOrDefault();
            if(parking.Name==f.Name)
            {
                ViewBag.Amount = 100;
                return View("Index");
            }
            
            return RedirectToAction("Index");
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

    }
}
